clear
echo
gcc main2.c port_utils.c output.c graphic.c input.c nonblock.c -o tp8b -g -Werror



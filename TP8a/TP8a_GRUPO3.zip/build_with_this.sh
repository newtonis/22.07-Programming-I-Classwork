clear
echo
gcc main.c port_utils.c output.c -o tp8a -g -Werror



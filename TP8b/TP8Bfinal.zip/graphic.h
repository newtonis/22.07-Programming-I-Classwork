#ifndef GRAPHIC_H
#define GRAPHIC_H

#include "port_utils.h"

void update_display(microPorts_t *mp,int *mode);

#endif // GRAPHIC_H